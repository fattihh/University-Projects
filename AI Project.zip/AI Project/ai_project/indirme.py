import gdown
import os
import shutil

indirilecek_yer = r""
dataset_klasoru = os.path.join(indirilecek_yer, "dataset")

# Var olan dataset klasörünü sil
if os.path.exists(dataset_klasoru):
    shutil.rmtree(dataset_klasoru)

# dataset klasörünü oluştur
os.makedirs(dataset_klasoru, exist_ok=True)

folders = {
    "1Yl9Xe1JYZPjEZQTDFHQaq9q1lpoJ5oIB": "ai_analiz",
    "1fF3KX2NZr_ZdIOzGeHLLvDZ72_GmPs7J": "ai_photo"
}

for folder_id, folder_name in folders.items():
    hedef_klasor = os.path.join(dataset_klasoru, folder_name)
    os.makedirs(hedef_klasor, exist_ok=True)
    url = f"https://drive.google.com/drive/folders/{folder_id}"
    print(f"İndiriliyor: {folder_name}")
    gdown.download_folder(url, output=hedef_klasor, quiet=False, use_cookies=True)

# Dosya uzantılarını değiştirme fonksiyonu
def change_extensions(folder_path, new_ext):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            eski_dosya = os.path.join(root, file)
            dosya_adi, _ = os.path.splitext(eski_dosya)
            yeni_dosya = dosya_adi + new_ext
            os.rename(eski_dosya, yeni_dosya)

# ai_analiz için .txt
change_extensions(os.path.join(dataset_klasoru, "ai_analiz"), ".txt")

# ai_photo için .jpg
change_extensions(os.path.join(dataset_klasoru, "ai_photo"), ".jpg")

print("Tüm klasörler indirildi ve dosya uzantıları değiştirildi.")
print("İşlem tamamlandı.")