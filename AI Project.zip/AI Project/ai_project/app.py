import streamlit as st
from pathlib import Path
from io import BytesIO
from gtts import gTTS
from gtts.tts import gTTSError

# ——— Sayfanın tüm genişliği kullansın ———
st.set_page_config(page_title="Haber Görüntüleyici", layout="wide")

# Eğer doğrudan `python app.py` ile çalıştırıldıysa uyarı ver
if not st.runtime.exists():
    st.warning(
        "Uygulamayı şu komutla çalıştırın:\n\n"
        "`streamlit run app.py`"
    )

# ——— Proje kök dizininden göreli yollar ———
BASE_DIR     = Path(__file__).parent
ANALYSIS_DIR = BASE_DIR / "dataset" / "ai_analiz"
PHOTO_DIR    = BASE_DIR / "dataset" / "ai_photo"

# ——— Yardımcı: dosyanın encoding'ini otomatik bul ———
def read_text_auto(path: Path) -> str:
    for enc in ("utf-8", "cp1254", "latin-1"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    try:
        import chardet
        raw_bytes = path.read_bytes()
        guessed = chardet.detect(raw_bytes)["encoding"] or "utf-8"
        return raw_bytes.decode(guessed, errors="replace")
    except ImportError:
        # chardet yoksa en son 'ignore' ile oku
        return path.read_text(encoding="utf-8", errors="ignore")

# 1) .txt dosyalarını al
txt_files = sorted(ANALYSIS_DIR.glob("*.txt"), key=lambda p: p.name.lower())
if not txt_files:
    st.warning("ANALYSIS_DIR içinde hiç .txt dosyası bulunamadı.")
    st.stop()

# 2) session_state’de idx
if "idx" not in st.session_state or st.session_state.idx >= len(txt_files):
    st.session_state.idx = 0

# 3) Navigasyon butonları (üstte, yatay)
nav_cols = st.columns([1,8,1])
with nav_cols[0]:
    if st.button("« Önceki") and st.session_state.idx > 0:
        st.session_state.idx -= 1
with nav_cols[2]:
    if st.button("Sonraki »") and st.session_state.idx < len(txt_files)-1:
        st.session_state.idx += 1

# 4) İçerik için iki kolon (metin:resim = 3:2)
col_text, col_image = st.columns([3,2], gap="large")

# 5) Geçerli .txt dosyasını oku
current_txt = txt_files[st.session_state.idx]
raw = read_text_auto(current_txt)
lines = raw.splitlines()

# 6) Başlık = ilk satır, içindeki tüm # karakterlerini temizle
if lines:
    title = lines[0].lstrip('#').strip()
    body_lines = lines[1:]
else:
    title = current_txt.stem
    body_lines = []

body_html = "<br>".join(body_lines)

# 7) Sol sütuna başlık ve metin
with col_text:
    st.markdown(
        f"<h2 style='font-weight:bold;margin-bottom:0.5em;'>{title}</h2>",
        unsafe_allow_html=True
    )
    st.markdown(
        f"<p style='font-size:16px; line-height:1.5; margin-top:0;'>{body_html}</p>",
        unsafe_allow_html=True
    )

# 8) Sağ sütunda resim (analiz önekini kırp ve hangi uzantıysa bul)
with col_image:
    stem = current_txt.stem
    if stem.lower().startswith("analiz "):
        stem = stem[len("analiz "):]
    allowed_exts = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
    candidates = [
        p for p in PHOTO_DIR.glob(f"{stem}.*")
        if p.suffix.lower() in allowed_exts
    ]
    if candidates:
        # sütunun kendi genişliğine göre otomatik boyut
        st.image(str(candidates[0]), use_column_width=True)
    else:
        st.warning("Resim bulunamadı.")

# 9) Sesli okuma: dosyanın tamamını oku (hata yönetimi ile)
if st.checkbox("Sesli oku"):
    try:
        text_to_speak = raw.strip()
        if not text_to_speak:
            st.info("Okunacak metin bulunamadı.")
        else:
            # Çok uzun metinler sorun çıkarıyorsa bölünebilir
            tts = gTTS(text=text_to_speak, lang="tr")
            mp3_fp = BytesIO()
            tts.write_to_fp(mp3_fp)
            mp3_fp.seek(0)
            st.audio(mp3_fp, format="audio/mp3")
    except gTTSError as e:
        st.error(f"Sesli okuma hatası: {e}")
    except Exception as e:
        st.error(f"Bilinmeyen hata: {e}")


